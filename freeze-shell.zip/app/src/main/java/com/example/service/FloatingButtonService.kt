package com.example.service

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.Typeface
import android.os.Build
import android.os.IBinder
import android.util.TypedValue
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.view.animation.LinearInterpolator
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.example.MainActivity
import com.example.R
import com.example.data.AppPreferencesRepository
import com.example.data.FreezeShellSettings
import com.example.shell.RootShellManager
import kotlin.math.hypot
import kotlin.math.roundToInt
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

object FloatingServiceState {
  private val _isRunning = MutableStateFlow(false)
  val isRunning: StateFlow<Boolean> = _isRunning.asStateFlow()

  internal fun setRunning(running: Boolean) {
    _isRunning.value = running
  }
}

class FloatingButtonService : Service() {

  private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
  private lateinit var windowManager: WindowManager
  private lateinit var preferencesRepository: AppPreferencesRepository

  private var floatingView: FloatingFreezeView? = null
  private var layoutParams: WindowManager.LayoutParams? = null
  private var currentSettings: FreezeShellSettings = FreezeShellSettings()

  override fun onCreate() {
    super.onCreate()
    windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
    preferencesRepository = AppPreferencesRepository(applicationContext)
    createNotificationChannel()
    startForegroundWithNotification(isLocked = false)
    FloatingServiceState.setRunning(true)

    serviceScope.launch {
      currentSettings = preferencesRepository.settingsFlow.first()
      attachFloatingButton(currentSettings)

      preferencesRepository.settingsFlow.collect { updated ->
        currentSettings = updated
        updateFloatingButton(updated)
      }
    }
  }

  override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
    if (intent?.action == ACTION_STOP) {
      stopSelf()
      return START_NOT_STICKY
    }
    return START_STICKY
  }

  override fun onDestroy() {
    FloatingServiceState.setRunning(false)
    removeFloatingButton()
    serviceScope.cancel()
    super.onDestroy()
  }

  override fun onBind(intent: Intent?): IBinder? = null

  private fun attachFloatingButton(settings: FreezeShellSettings) {
    if (floatingView != null) return

    val sizePx = dpToPx(settings.buttonSizeDp)
    val windowType =
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
      } else {
        @Suppress("DEPRECATION")
        WindowManager.LayoutParams.TYPE_PHONE
      }

    val params =
      WindowManager.LayoutParams(
        sizePx,
        sizePx,
        windowType,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
        PixelFormat.TRANSLUCENT,
      ).apply {
        gravity = Gravity.TOP or Gravity.START
        val (clampedX, clampedY) = clampToScreen(settings.buttonX, settings.buttonY, sizePx)
        x = clampedX
        y = clampedY
      }

    val view =
      FloatingFreezeView(
        context = this,
        onTapToggle = { handleFreezeTap() },
        onToggleLock = { handleToggleLock() },
        onMovePosition = { newX, newY ->
          val currentSizePx = params.width
          val (cx, cy) = clampToScreen(newX, newY, currentSizePx)
          params.x = cx
          params.y = cy
          runCatching { windowManager.updateViewLayout(floatingView, params) }
        },
        onCommitPosition = { finalX, finalY ->
          serviceScope.launch { preferencesRepository.setButtonPosition(finalX, finalY) }
        },
      ).apply {
        setState(isGreen = settings.isGreenState, isLocked = settings.isLocked)
      }

    layoutParams = params
    floatingView = view
    runCatching { windowManager.addView(view, params) }
  }

  private fun updateFloatingButton(settings: FreezeShellSettings) {
    val view = floatingView ?: return
    val params = layoutParams ?: return

    view.setState(isGreen = settings.isGreenState, isLocked = settings.isLocked)

    val targetSizePx = dpToPx(settings.buttonSizeDp)
    if (params.width != targetSizePx || params.height != targetSizePx) {
      params.width = targetSizePx
      params.height = targetSizePx
      val (cx, cy) = clampToScreen(params.x, params.y, targetSizePx)
      params.x = cx
      params.y = cy
      runCatching { windowManager.updateViewLayout(view, params) }
    }
  }

  private fun removeFloatingButton() {
    floatingView?.let { view ->
      view.cancelHoldAnimator()
      runCatching { windowManager.removeView(view) }
    }
    floatingView = null
    layoutParams = null
  }

  private fun handleFreezeTap() {
    val nextGreenState = !currentSettings.isGreenState
    val commandToRun =
      if (nextGreenState) {
        currentSettings.topShellCommand
      } else {
        currentSettings.bottomShellCommand
      }

    currentSettings = currentSettings.copy(isGreenState = nextGreenState)
    floatingView?.setState(isGreen = nextGreenState, isLocked = currentSettings.isLocked)

    serviceScope.launch {
      preferencesRepository.setGreenState(nextGreenState)
      if (commandToRun.isBlank()) {
        Toast.makeText(
          this@FloatingButtonService,
          getString(R.string.command_empty_toast),
          Toast.LENGTH_SHORT,
        ).show()
      } else {
        val result =
          RootShellManager.executeRootCommand(
            command = commandToRun,
            isGreenCommand = nextGreenState,
          )
        if (!result.success && result.output.isNotBlank()) {
          Toast.makeText(
            this@FloatingButtonService,
            result.output.take(120),
            Toast.LENGTH_SHORT,
          ).show()
        }
      }
    }
  }

  private fun handleToggleLock() {
    val nextLocked = !currentSettings.isLocked
    currentSettings = currentSettings.copy(isLocked = nextLocked)
    floatingView?.setState(isGreen = currentSettings.isGreenState, isLocked = nextLocked)
    startForegroundWithNotification(isLocked = nextLocked)

    val messageRes =
      if (nextLocked) R.string.button_locked_toast else R.string.button_unlocked_toast
    Toast.makeText(this, getString(messageRes), Toast.LENGTH_SHORT).show()

    serviceScope.launch { preferencesRepository.setLocked(nextLocked) }
  }

  private fun clampToScreen(x: Int, y: Int, viewSizePx: Int): Pair<Int, Int> {
    val metrics = resources.displayMetrics
    val maxX = (metrics.widthPixels - viewSizePx).coerceAtLeast(0)
    val maxY = (metrics.heightPixels - viewSizePx).coerceAtLeast(0)
    return x.coerceIn(0, maxX) to y.coerceIn(0, maxY)
  }

  private fun dpToPx(dp: Int): Int {
    return TypedValue.applyDimension(
      TypedValue.COMPLEX_UNIT_DIP,
      dp.toFloat(),
      resources.displayMetrics,
    ).roundToInt()
  }

  private fun createNotificationChannel() {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
      val channel =
        NotificationChannel(
          CHANNEL_ID,
          getString(R.string.notification_channel_name),
          NotificationManager.IMPORTANCE_LOW,
        ).apply {
          setShowBadge(false)
        }
      val manager = getSystemService(NotificationManager::class.java)
      manager.createNotificationChannel(channel)
    }
  }

  private fun startForegroundWithNotification(isLocked: Boolean) {
    val notification = buildNotification(isLocked)
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
      ServiceCompat.startForeground(
        this,
        NOTIFICATION_ID,
        notification,
        ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE,
      )
    } else {
      startForeground(NOTIFICATION_ID, notification)
    }
  }

  private fun buildNotification(isLocked: Boolean): Notification {
    val openAppIntent =
      PendingIntent.getActivity(
        this,
        0,
        Intent(this, MainActivity::class.java).apply {
          flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        },
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
      )

    val stopIntent =
      PendingIntent.getService(
        this,
        1,
        Intent(this, FloatingButtonService::class.java).apply { action = ACTION_STOP },
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
      )

    val contentText =
      if (isLocked) {
        getString(R.string.notification_text_locked)
      } else {
        getString(R.string.notification_text_unlocked)
      }

    return NotificationCompat.Builder(this, CHANNEL_ID)
      .setSmallIcon(R.drawable.ic_notification_freeze)
      .setContentTitle(getString(R.string.notification_title))
      .setContentText(contentText)
      .setContentIntent(openAppIntent)
      .setOngoing(true)
      .setSilent(true)
      .addAction(0, getString(R.string.disable_floating_button), stopIntent)
      .build()
  }

  companion object {
    private const val CHANNEL_ID = "freeze_shell_overlay_channel"
    private const val NOTIFICATION_ID = 1001
    private const val ACTION_STOP = "com.example.action.STOP_FLOATING_BUTTON"

    fun start(context: Context) {
      val intent = Intent(context, FloatingButtonService::class.java)
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        context.startForegroundService(intent)
      } else {
        context.startService(intent)
      }
    }

    fun stop(context: Context) {
      context.stopService(Intent(context, FloatingButtonService::class.java))
    }
  }
}

@SuppressLint("ViewConstructor")
private class FloatingFreezeView(
  context: Context,
  private val onTapToggle: () -> Unit,
  private val onToggleLock: () -> Unit,
  private val onMovePosition: (Int, Int) -> Unit,
  private val onCommitPosition: (Int, Int) -> Unit,
) : View(context) {

  private var isGreen: Boolean = false
  private var isLocked: Boolean = false
  private var holdProgress: Float = 0f

  private val touchSlop = ViewConfiguration.get(context).scaledTouchSlop
  private var initialTouchX = 0f
  private var initialTouchY = 0f
  private var initialWindowX = 0
  private var initialWindowY = 0
  private var isDragging = false
  private var longPressTriggered = false
  private var holdAnimator: ValueAnimator? = null

  private val circlePaint = Paint(Paint.ANTI_ALIAS_FLAG)
  private val borderPaint =
    Paint(Paint.ANTI_ALIAS_FLAG).apply {
      style = Paint.Style.STROKE
      color = Color.argb(190, 255, 255, 255)
    }
  private val progressPaint =
    Paint(Paint.ANTI_ALIAS_FLAG).apply {
      style = Paint.Style.STROKE
      strokeCap = Paint.Cap.ROUND
      color = Color.WHITE
    }
  private val textPaint =
    Paint(Paint.ANTI_ALIAS_FLAG).apply {
      color = Color.WHITE
      textAlign = Paint.Align.CENTER
      typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
    }
  private val lockPaint =
    Paint(Paint.ANTI_ALIAS_FLAG).apply {
      color = Color.argb(235, 255, 255, 255)
      style = Paint.Style.STROKE
      strokeCap = Paint.Cap.ROUND
    }
  private val lockBodyPaint =
    Paint(Paint.ANTI_ALIAS_FLAG).apply {
      color = Color.argb(235, 255, 255, 255)
      style = Paint.Style.FILL
    }
  private val arcRect = RectF()
  private val lockRect = RectF()

  fun setState(isGreen: Boolean, isLocked: Boolean) {
    this.isGreen = isGreen
    this.isLocked = isLocked
    invalidate()
  }

  fun cancelHoldAnimator() {
    holdAnimator?.cancel()
    holdAnimator = null
    holdProgress = 0f
    invalidate()
  }

  override fun onDraw(canvas: Canvas) {
    super.onDraw(canvas)
    val w = width.toFloat()
    val h = height.toFloat()
    val size = minOf(w, h)
    if (size <= 0f) return

    val cx = w / 2f
    val cy = h / 2f
    val padding = size * 0.05f
    val radius = (size / 2f) - padding

    circlePaint.color =
      if (isGreen) {
        0xFF2E7D32.toInt()
      } else {
        0xFFC62828.toInt()
      }
    canvas.drawCircle(cx, cy, radius, circlePaint)

    if (isLocked) {
      borderPaint.strokeWidth = (size * 0.032f).coerceAtLeast(3f)
      canvas.drawCircle(cx, cy, radius - borderPaint.strokeWidth / 2f, borderPaint)
    }

    if (holdProgress > 0f) {
      val stroke = (size * 0.055f).coerceAtLeast(4f)
      progressPaint.strokeWidth = stroke
      val inset = padding + stroke / 2f
      arcRect.set(inset, inset, w - inset, h - inset)
      canvas.drawArc(arcRect, -90f, 360f * holdProgress, false, progressPaint)
    }

    textPaint.textSize = size * 0.21f
    val fontMetrics = textPaint.fontMetrics
    val textBaselineOffset = -(fontMetrics.ascent + fontMetrics.descent) / 2f
    val labelY =
      if (isLocked) {
        cy + textBaselineOffset - size * 0.06f
      } else {
        cy + textBaselineOffset
      }
    canvas.drawText(context.getString(R.string.freeze_button_text), cx, labelY, textPaint)

    if (isLocked) {
      drawLockBadge(canvas, cx, cy + size * 0.20f, size * 0.14f)
    }
  }

  private fun drawLockBadge(canvas: Canvas, cx: Float, cy: Float, badgeSize: Float) {
    val bodyW = badgeSize * 0.95f
    val bodyH = badgeSize * 0.68f
    val shackleRadius = bodyW * 0.30f

    lockPaint.strokeWidth = (badgeSize * 0.16f).coerceAtLeast(2f)
    val shackleCenterY = cy - bodyH * 0.25f
    arcRect.set(
      cx - shackleRadius,
      shackleCenterY - shackleRadius,
      cx + shackleRadius,
      shackleCenterY + shackleRadius,
    )
    canvas.drawArc(arcRect, 180f, 180f, false, lockPaint)

    val top = cy - bodyH * 0.25f
    lockRect.set(cx - bodyW / 2f, top, cx + bodyW / 2f, top + bodyH)
    canvas.drawRoundRect(lockRect, badgeSize * 0.16f, badgeSize * 0.16f, lockBodyPaint)
  }

  @SuppressLint("ClickableViewAccessibility")
  override fun onTouchEvent(event: MotionEvent): Boolean {
    val params = layoutParams as? WindowManager.LayoutParams ?: return false

    when (event.actionMasked) {
      MotionEvent.ACTION_DOWN -> {
        initialTouchX = event.rawX
        initialTouchY = event.rawY
        initialWindowX = params.x
        initialWindowY = params.y
        isDragging = false
        longPressTriggered = false
        startHoldTimer()
        return true
      }

      MotionEvent.ACTION_MOVE -> {
        val dx = event.rawX - initialTouchX
        val dy = event.rawY - initialTouchY
        val distance = hypot(dx, dy)

        if (!longPressTriggered) {
          if (!isLocked) {
            if (!isDragging && distance > touchSlop) {
              isDragging = true
              cancelHoldAnimator()
            }
            if (isDragging) {
              onMovePosition(
                (initialWindowX + dx).roundToInt(),
                (initialWindowY + dy).roundToInt(),
              )
            }
          } else {
            if (distance > touchSlop * 2.5f) {
              cancelHoldAnimator()
            }
          }
        }
        return true
      }

      MotionEvent.ACTION_UP -> {
        cancelHoldAnimator()
        if (!longPressTriggered) {
          if (isDragging) {
            onCommitPosition(params.x, params.y)
          } else {
            performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
            onTapToggle()
          }
        }
        return true
      }

      MotionEvent.ACTION_CANCEL -> {
        cancelHoldAnimator()
        return true
      }
    }
    return super.onTouchEvent(event)
  }

  private fun startHoldTimer() {
    cancelHoldAnimator()
    var completedNaturally = true
    val animator =
      ValueAnimator.ofFloat(0f, 1f).apply {
        startDelay = HOLD_FEEDBACK_DELAY_MS
        duration = HOLD_LOCK_DURATION_MS - HOLD_FEEDBACK_DELAY_MS
        interpolator = LinearInterpolator()
        addUpdateListener { anim ->
          holdProgress = anim.animatedValue as Float
          invalidate()
        }
        addListener(
          object : AnimatorListenerAdapter() {
            override fun onAnimationCancel(animation: Animator) {
              completedNaturally = false
            }

            override fun onAnimationEnd(animation: Animator) {
              if (completedNaturally && !longPressTriggered) {
                longPressTriggered = true
                holdProgress = 0f
                invalidate()
                performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                onToggleLock()
              }
            }
          },
        )
      }
    holdAnimator = animator
    animator.start()
  }

  companion object {
    private const val HOLD_LOCK_DURATION_MS = 2000L
    private const val HOLD_FEEDBACK_DELAY_MS = 200L
  }
}
