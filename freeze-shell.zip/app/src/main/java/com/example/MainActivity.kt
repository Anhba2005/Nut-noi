package com.example

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.MainScreen
import com.example.ui.MainViewModel
import com.example.ui.theme.FreezeShellTheme

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      FreezeShellTheme {
        val context = LocalContext.current
        val viewModel: MainViewModel = viewModel()
        val uiState by viewModel.uiState.collectAsStateWithLifecycle()
        var pendingStartAfterOverlay by remember { mutableStateOf(false) }

        val notificationPermissionLauncher =
          rememberLauncherForActivityResult(
            contract = ActivityResultContracts.RequestPermission(),
          ) {
            viewModel.toggleFloatingButton(
              canDrawOverlays = Settings.canDrawOverlays(context),
              onRequestOverlayPermission = {},
            )
          }

        val overlayPermissionLauncher =
          rememberLauncherForActivityResult(
            contract = ActivityResultContracts.StartActivityForResult(),
          ) {
            if (pendingStartAfterOverlay) {
              pendingStartAfterOverlay = false
              if (Settings.canDrawOverlays(context)) {
                viewModel.startFloatingServiceWithCurrentConfig()
              } else {
                viewModel.showMessage(getString(R.string.overlay_permission_needed))
              }
            }
          }

        val launchOverlaySettings = {
          pendingStartAfterOverlay = true
          val intent =
            Intent(
              Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
              Uri.parse("package:${context.packageName}"),
            )
          overlayPermissionLauncher.launch(intent)
        }

        val handleToggleFloating = {
          val canDraw = Settings.canDrawOverlays(context)
          if (!uiState.isFloatingEnabled && canDraw && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val hasNotifPermission =
              ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS,
              ) == PackageManager.PERMISSION_GRANTED
            if (!hasNotifPermission) {
              notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            } else {
              viewModel.toggleFloatingButton(
                canDrawOverlays = true,
                onRequestOverlayPermission = launchOverlaySettings,
              )
            }
          } else {
            viewModel.toggleFloatingButton(
              canDrawOverlays = canDraw,
              onRequestOverlayPermission = launchOverlaySettings,
            )
          }
        }

        MainScreen(
          uiState = uiState,
          onTopShellChanged = viewModel::onTopShellChanged,
          onBottomShellChanged = viewModel::onBottomShellChanged,
          onSaveConfig = viewModel::saveConfig,
          onToggleFloatingButton = handleToggleFloating,
          onButtonSizeChanged = viewModel::onButtonSizeChanged,
          onRequestRoot = viewModel::requestRootPermission,
          onSnackbarShown = viewModel::clearSnackbar,
        )
      }
    }
  }
}
