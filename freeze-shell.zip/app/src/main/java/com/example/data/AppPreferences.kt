package com.example.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import java.io.IOException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "freeze_shell_prefs")

data class FreezeShellSettings(
  val topShellCommand: String = "",
  val bottomShellCommand: String = "",
  val buttonSizeDp: Int = DEFAULT_BUTTON_SIZE_DP,
  val buttonX: Int = DEFAULT_BUTTON_X,
  val buttonY: Int = DEFAULT_BUTTON_Y,
  val isLocked: Boolean = false,
  val isGreenState: Boolean = false,
) {
  companion object {
    const val MIN_BUTTON_SIZE_DP = 48
    const val MAX_BUTTON_SIZE_DP = 140
    const val DEFAULT_BUTTON_SIZE_DP = 82
    const val DEFAULT_BUTTON_X = 720
    const val DEFAULT_BUTTON_Y = 260
  }
}

class AppPreferencesRepository(private val context: Context) {

  private object Keys {
    val TOP_SHELL_COMMAND = stringPreferencesKey("top_shell_command")
    val BOTTOM_SHELL_COMMAND = stringPreferencesKey("bottom_shell_command")
    val BUTTON_SIZE_DP = intPreferencesKey("button_size_dp")
    val BUTTON_X = intPreferencesKey("button_x")
    val BUTTON_Y = intPreferencesKey("button_y")
    val IS_LOCKED = booleanPreferencesKey("is_locked")
    val IS_GREEN_STATE = booleanPreferencesKey("is_green_state")
  }

  val settingsFlow: Flow<FreezeShellSettings> =
    context.dataStore.data
      .catch { exception ->
        if (exception is IOException) {
          emit(emptyPreferences())
        } else {
          throw exception
        }
      }
      .map { prefs ->
        FreezeShellSettings(
          topShellCommand = prefs[Keys.TOP_SHELL_COMMAND] ?: "",
          bottomShellCommand = prefs[Keys.BOTTOM_SHELL_COMMAND] ?: "",
          buttonSizeDp =
            (prefs[Keys.BUTTON_SIZE_DP] ?: FreezeShellSettings.DEFAULT_BUTTON_SIZE_DP)
              .coerceIn(
                FreezeShellSettings.MIN_BUTTON_SIZE_DP,
                FreezeShellSettings.MAX_BUTTON_SIZE_DP,
              ),
          buttonX = prefs[Keys.BUTTON_X] ?: FreezeShellSettings.DEFAULT_BUTTON_X,
          buttonY = prefs[Keys.BUTTON_Y] ?: FreezeShellSettings.DEFAULT_BUTTON_Y,
          isLocked = prefs[Keys.IS_LOCKED] ?: false,
          isGreenState = prefs[Keys.IS_GREEN_STATE] ?: false,
        )
      }

  suspend fun saveShellCommands(topCommand: String, bottomCommand: String) {
    context.dataStore.edit { prefs ->
      prefs[Keys.TOP_SHELL_COMMAND] = topCommand
      prefs[Keys.BOTTOM_SHELL_COMMAND] = bottomCommand
    }
  }

  suspend fun setButtonSizeDp(sizeDp: Int) {
    val clamped =
      sizeDp.coerceIn(
        FreezeShellSettings.MIN_BUTTON_SIZE_DP,
        FreezeShellSettings.MAX_BUTTON_SIZE_DP,
      )
    context.dataStore.edit { prefs -> prefs[Keys.BUTTON_SIZE_DP] = clamped }
  }

  suspend fun setButtonPosition(x: Int, y: Int) {
    context.dataStore.edit { prefs ->
      prefs[Keys.BUTTON_X] = x
      prefs[Keys.BUTTON_Y] = y
    }
  }

  suspend fun setLocked(locked: Boolean) {
    context.dataStore.edit { prefs -> prefs[Keys.IS_LOCKED] = locked }
  }

  suspend fun setGreenState(isGreen: Boolean) {
    context.dataStore.edit { prefs -> prefs[Keys.IS_GREEN_STATE] = isGreen }
  }
}
