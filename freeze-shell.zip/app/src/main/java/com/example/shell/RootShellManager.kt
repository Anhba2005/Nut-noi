package com.example.shell

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull

enum class RootStatus {
  CHECKING,
  GRANTED,
  DENIED,
}

data class ShellExecutionResult(
  val command: String,
  val isGreenCommand: Boolean,
  val exitCode: Int,
  val output: String,
  val success: Boolean,
  val timestampMillis: Long = System.currentTimeMillis(),
)

object RootShellManager {

  private val _lastExecutionResult = MutableStateFlow<ShellExecutionResult?>(null)
  val lastExecutionResult: StateFlow<ShellExecutionResult?> = _lastExecutionResult.asStateFlow()

  suspend fun checkAndRequestRoot(): RootStatus =
    withContext(Dispatchers.IO) {
      val outcome =
        withTimeoutOrNull(12_000L) {
          runCatching {
            val process = ProcessBuilder("su").redirectErrorStream(true).start()
            process.outputStream.bufferedWriter().use { writer ->
              writer.write("id")
              writer.newLine()
              writer.write("exit")
              writer.newLine()
              writer.flush()
            }
            val output = process.inputStream.bufferedReader().use { it.readText() }
            val exitCode = process.waitFor()
            exitCode == 0 && output.contains("uid=0")
          }.getOrDefault(false)
        } ?: false

      if (outcome) RootStatus.GRANTED else RootStatus.DENIED
    }

  suspend fun executeRootCommand(
    command: String,
    isGreenCommand: Boolean,
  ): ShellExecutionResult =
    withContext(Dispatchers.IO) {
      val trimmed = command.trim()
      if (trimmed.isEmpty()) {
        val emptyResult =
          ShellExecutionResult(
            command = "",
            isGreenCommand = isGreenCommand,
            exitCode = -1,
            output = "Chưa có lệnh shell để thực thi.",
            success = false,
          )
        _lastExecutionResult.value = emptyResult
        return@withContext emptyResult
      }

      val result =
        withTimeoutOrNull(15_000L) {
          runCatching {
            val process = ProcessBuilder("su").redirectErrorStream(true).start()
            process.outputStream.bufferedWriter().use { writer ->
              writer.write(trimmed)
              writer.newLine()
              writer.write("exit")
              writer.newLine()
              writer.flush()
            }
            val output = process.inputStream.bufferedReader().use { it.readText().trim() }
            val exitCode = process.waitFor()
            ShellExecutionResult(
              command = trimmed,
              isGreenCommand = isGreenCommand,
              exitCode = exitCode,
              output = output,
              success = exitCode == 0,
            )
          }.getOrElse { throwable ->
            ShellExecutionResult(
              command = trimmed,
              isGreenCommand = isGreenCommand,
              exitCode = -1,
              output = throwable.localizedMessage ?: "Không thể gọi su (thiết bị chưa root hoặc bị từ chối).",
              success = false,
            )
          }
        }
          ?: ShellExecutionResult(
            command = trimmed,
            isGreenCommand = isGreenCommand,
            exitCode = -1,
            output = "Lệnh shell quá thời gian phản hồi (timeout 15s).",
            success = false,
          )

      _lastExecutionResult.value = result
      result
    }
}
