package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.R
import com.example.data.AppPreferencesRepository
import com.example.data.FreezeShellSettings
import com.example.service.FloatingButtonService
import com.example.service.FloatingServiceState
import com.example.shell.RootShellManager
import com.example.shell.RootStatus
import com.example.shell.ShellExecutionResult
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class MainUiState(
  val rootStatus: RootStatus = RootStatus.CHECKING,
  val topShellInput: String = "",
  val bottomShellInput: String = "",
  val buttonSizeDp: Int = FreezeShellSettings.DEFAULT_BUTTON_SIZE_DP,
  val isFloatingEnabled: Boolean = false,
  val isLocked: Boolean = false,
  val isGreenState: Boolean = false,
  val lastResult: ShellExecutionResult? = null,
  val snackbarMessage: String? = null,
)

class MainViewModel(application: Application) : AndroidViewModel(application) {

  private val preferencesRepository = AppPreferencesRepository(application.applicationContext)

  private val _uiState = MutableStateFlow(MainUiState())
  val uiState: StateFlow<MainUiState> = _uiState.asStateFlow()

  private var inputsInitialized = false

  init {
    requestRootPermission()
    observeSettings()
    observeRuntimeState()
  }

  private fun observeSettings() {
    viewModelScope.launch {
      val initial = preferencesRepository.settingsFlow.first()
      if (!inputsInitialized) {
        inputsInitialized = true
        _uiState.update {
          it.copy(
            topShellInput = initial.topShellCommand,
            bottomShellInput = initial.bottomShellCommand,
            buttonSizeDp = initial.buttonSizeDp,
            isLocked = initial.isLocked,
            isGreenState = initial.isGreenState,
          )
        }
      }

      preferencesRepository.settingsFlow.collect { settings ->
        _uiState.update {
          it.copy(
            buttonSizeDp = settings.buttonSizeDp,
            isLocked = settings.isLocked,
            isGreenState = settings.isGreenState,
          )
        }
      }
    }
  }

  private fun observeRuntimeState() {
    viewModelScope.launch {
      FloatingServiceState.isRunning.collect { running ->
        _uiState.update { it.copy(isFloatingEnabled = running) }
      }
    }
    viewModelScope.launch {
      RootShellManager.lastExecutionResult.collect { result ->
        _uiState.update { it.copy(lastResult = result) }
      }
    }
  }

  fun requestRootPermission() {
    viewModelScope.launch {
      _uiState.update { it.copy(rootStatus = RootStatus.CHECKING) }
      val status = RootShellManager.checkAndRequestRoot()
      _uiState.update { it.copy(rootStatus = status) }
    }
  }

  fun onTopShellChanged(value: String) {
    _uiState.update { it.copy(topShellInput = value) }
  }

  fun onBottomShellChanged(value: String) {
    _uiState.update { it.copy(bottomShellInput = value) }
  }

  fun onButtonSizeChanged(sizeDp: Int) {
    val clamped =
      sizeDp.coerceIn(
        FreezeShellSettings.MIN_BUTTON_SIZE_DP,
        FreezeShellSettings.MAX_BUTTON_SIZE_DP,
      )
    _uiState.update { it.copy(buttonSizeDp = clamped) }
    viewModelScope.launch { preferencesRepository.setButtonSizeDp(clamped) }
  }

  fun saveConfig() {
    val state = _uiState.value
    viewModelScope.launch {
      preferencesRepository.saveShellCommands(
        topCommand = state.topShellInput,
        bottomCommand = state.bottomShellInput,
      )
      _uiState.update {
        it.copy(
          snackbarMessage = getApplication<Application>().getString(R.string.config_saved_message),
        )
      }
    }
  }

  fun toggleFloatingButton(
    canDrawOverlays: Boolean,
    onRequestOverlayPermission: () -> Unit,
  ) {
    val app = getApplication<Application>()
    if (_uiState.value.isFloatingEnabled) {
      FloatingButtonService.stop(app)
      return
    }

    if (!canDrawOverlays) {
      _uiState.update {
        it.copy(snackbarMessage = app.getString(R.string.overlay_permission_needed))
      }
      onRequestOverlayPermission()
      return
    }

    startFloatingServiceWithCurrentConfig()
  }

  fun startFloatingServiceWithCurrentConfig() {
    val app = getApplication<Application>()
    val state = _uiState.value
    viewModelScope.launch {
      preferencesRepository.saveShellCommands(
        topCommand = state.topShellInput,
        bottomCommand = state.bottomShellInput,
      )
      FloatingButtonService.start(app)
    }
  }

  fun showMessage(message: String) {
    _uiState.update { it.copy(snackbarMessage = message) }
  }

  fun clearSnackbar() {
    _uiState.update { it.copy(snackbarMessage = null) }
  }
}
