package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.LockOpen
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Terminal
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.FreezeShellSettings
import com.example.shell.RootStatus
import com.example.shell.ShellExecutionResult
import com.example.ui.theme.FreezeGreen
import com.example.ui.theme.FreezeRedBright
import com.example.ui.theme.FreezeShellTheme
import kotlin.math.roundToInt

@Composable
fun MainScreen(
  uiState: MainUiState,
  onTopShellChanged: (String) -> Unit,
  onBottomShellChanged: (String) -> Unit,
  onSaveConfig: () -> Unit,
  onToggleFloatingButton: () -> Unit,
  onButtonSizeChanged: (Int) -> Unit,
  onRequestRoot: () -> Unit,
  onSnackbarShown: () -> Unit,
) {
  val snackbarHostState = remember { SnackbarHostState() }

  LaunchedEffect(uiState.snackbarMessage) {
    val msg = uiState.snackbarMessage
    if (!msg.isNullOrBlank()) {
      snackbarHostState.showSnackbar(msg)
      onSnackbarShown()
    }
  }

  Scaffold(
    modifier = Modifier.fillMaxSize(),
    containerColor = MaterialTheme.colorScheme.background,
    contentWindowInsets = WindowInsets.safeDrawing,
    snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
  ) { innerPadding ->
    Box(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding)
        .imePadding(),
      contentAlignment = Alignment.TopCenter,
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .widthIn(max = 600.dp)
          .verticalScroll(rememberScrollState())
          .padding(horizontal = 20.dp, vertical = 20.dp),
      ) {
        Spacer(modifier = Modifier.height(12.dp))

        Text(
          text = stringResource(R.string.greeting_title),
          style = MaterialTheme.typography.headlineLarge,
          fontWeight = FontWeight.Normal,
          color = MaterialTheme.colorScheme.onBackground,
          modifier = Modifier.testTag("greeting_title"),
        )

        Spacer(modifier = Modifier.height(10.dp))

        RootStatusRow(
          rootStatus = uiState.rootStatus,
          onRequestRoot = onRequestRoot,
        )

        Spacer(modifier = Modifier.height(20.dp))

        ShellCommandBox(
          value = uiState.topShellInput,
          onValueChange = onTopShellChanged,
          indicatorColor = FreezeGreen,
          helperLabel = stringResource(R.string.shell_top_label),
          testTag = "top_shell_input",
        )

        Spacer(modifier = Modifier.height(16.dp))

        ShellCommandBox(
          value = uiState.bottomShellInput,
          onValueChange = onBottomShellChanged,
          indicatorColor = FreezeRedBright,
          helperLabel = stringResource(R.string.shell_bottom_label),
          testTag = "bottom_shell_input",
        )

        Spacer(modifier = Modifier.height(18.dp))

        Button(
          onClick = onSaveConfig,
          modifier = Modifier
            .fillMaxWidth()
            .height(48.dp)
            .testTag("save_config_button"),
          shape = RoundedCornerShape(8.dp),
          colors = ButtonDefaults.buttonColors(
            containerColor = MaterialTheme.colorScheme.primary,
            contentColor = MaterialTheme.colorScheme.onPrimary,
          ),
          contentPadding = PaddingValues(horizontal = 16.dp),
        ) {
          Text(
            text = stringResource(R.string.save_config),
            style = MaterialTheme.typography.labelLarge,
            fontWeight = FontWeight.Medium,
          )
        }

        Spacer(modifier = Modifier.height(12.dp))

        Button(
          onClick = onToggleFloatingButton,
          modifier = Modifier
            .fillMaxWidth()
            .height(48.dp)
            .testTag("toggle_floating_button"),
          shape = RoundedCornerShape(8.dp),
          colors = ButtonDefaults.buttonColors(
            containerColor = MaterialTheme.colorScheme.primary,
            contentColor = MaterialTheme.colorScheme.onPrimary,
          ),
          contentPadding = PaddingValues(horizontal = 16.dp),
        ) {
          Text(
            text =
              if (uiState.isFloatingEnabled) {
                stringResource(R.string.disable_floating_button)
              } else {
                stringResource(R.string.enable_floating_button)
              },
            style = MaterialTheme.typography.labelLarge,
            fontWeight = FontWeight.Medium,
          )
        }

        Spacer(modifier = Modifier.height(22.dp))

        Text(
          text = stringResource(R.string.button_size_label, uiState.buttonSizeDp),
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.Normal,
          color = MaterialTheme.colorScheme.onBackground,
          modifier = Modifier.testTag("button_size_label"),
        )

        Spacer(modifier = Modifier.height(4.dp))

        Slider(
          value = uiState.buttonSizeDp.toFloat(),
          onValueChange = { onButtonSizeChanged(it.roundToInt()) },
          valueRange =
            FreezeShellSettings.MIN_BUTTON_SIZE_DP.toFloat()..
              FreezeShellSettings.MAX_BUTTON_SIZE_DP.toFloat(),
          colors =
            SliderDefaults.colors(
              thumbColor = FreezeRedBright,
              activeTrackColor = FreezeRedBright,
              inactiveTrackColor = FreezeRedBright.copy(alpha = 0.16f),
            ),
          modifier = Modifier
            .fillMaxWidth()
            .testTag("button_size_slider"),
        )

        Spacer(modifier = Modifier.height(12.dp))

        LockStatusCard(isLocked = uiState.isLocked)

        AnimatedVisibility(visible = uiState.lastResult != null) {
          uiState.lastResult?.let { result ->
            Column {
              Spacer(modifier = Modifier.height(12.dp))
              LastExecutionCard(result = result)
            }
          }
        }

        Spacer(modifier = Modifier.height(16.dp))
      }
    }
  }
}

@Composable
private fun RootStatusRow(
  rootStatus: RootStatus,
  onRequestRoot: () -> Unit,
) {
  val statusText =
    when (rootStatus) {
      RootStatus.CHECKING -> stringResource(R.string.root_checking)
      RootStatus.GRANTED -> stringResource(R.string.root_granted)
      RootStatus.DENIED -> stringResource(R.string.root_denied)
    }

  val statusColor =
    when (rootStatus) {
      RootStatus.CHECKING -> MaterialTheme.colorScheme.onSurfaceVariant
      RootStatus.GRANTED -> MaterialTheme.colorScheme.onBackground
      RootStatus.DENIED -> FreezeRedBright
    }

  Row(
    modifier = Modifier.fillMaxWidth(),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.SpaceBetween,
  ) {
    Text(
      text = "${stringResource(R.string.root_status_prefix)} $statusText",
      style = MaterialTheme.typography.bodyLarge,
      color = statusColor,
      modifier = Modifier
        .weight(1f)
        .testTag("root_status_text"),
    )

    if (rootStatus != RootStatus.GRANTED) {
      TextButton(
        onClick = onRequestRoot,
        modifier = Modifier.testTag("request_root_button"),
      ) {
        Icon(
          imageVector = Icons.Rounded.Refresh,
          contentDescription = stringResource(R.string.root_request_action),
          modifier = Modifier.size(18.dp),
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(text = stringResource(R.string.root_request_action))
      }
    }
  }
}

@Composable
private fun ShellCommandBox(
  value: String,
  onValueChange: (String) -> Unit,
  indicatorColor: Color,
  helperLabel: String,
  testTag: String,
) {
  Column(modifier = Modifier.fillMaxWidth()) {
    Row(
      verticalAlignment = Alignment.CenterVertically,
      modifier = Modifier.padding(bottom = 6.dp),
    ) {
      Box(
        modifier = Modifier
          .size(8.dp)
          .clip(CircleShape)
          .background(indicatorColor),
      )
      Spacer(modifier = Modifier.width(8.dp))
      Text(
        text = helperLabel,
        style = MaterialTheme.typography.labelMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
      )
    }

    OutlinedTextField(
      value = value,
      onValueChange = onValueChange,
      placeholder = {
        Text(
          text = stringResource(R.string.shell_placeholder),
          style = MaterialTheme.typography.bodyLarge,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
      },
      minLines = 4,
      maxLines = 7,
      shape = RoundedCornerShape(8.dp),
      colors =
        OutlinedTextFieldDefaults.colors(
          focusedBorderColor = MaterialTheme.colorScheme.primary,
          unfocusedBorderColor = MaterialTheme.colorScheme.primary,
          focusedContainerColor = MaterialTheme.colorScheme.surfaceContainerLow,
          unfocusedContainerColor = MaterialTheme.colorScheme.surfaceContainerLow,
        ),
      modifier = Modifier
        .fillMaxWidth()
        .heightIn(min = 124.dp)
        .testTag(testTag),
    )
  }
}

@Composable
private fun LockStatusCard(isLocked: Boolean) {
  Surface(
    shape = RoundedCornerShape(10.dp),
    color = MaterialTheme.colorScheme.surfaceContainerLow,
    tonalElevation = 1.dp,
    modifier = Modifier.fillMaxWidth(),
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 14.dp, vertical = 12.dp),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Icon(
        imageVector = if (isLocked) Icons.Rounded.Lock else Icons.Rounded.LockOpen,
        contentDescription = null,
        tint = if (isLocked) FreezeRedBright else MaterialTheme.colorScheme.primary,
        modifier = Modifier.size(20.dp),
      )
      Spacer(modifier = Modifier.width(10.dp))
      Column(modifier = Modifier.weight(1f)) {
        Text(
          text =
            if (isLocked) {
              "Vị trí nút nổi: Đang khoá"
            } else {
              "Vị trí nút nổi: Có thể kéo di chuyển"
            },
          style = MaterialTheme.typography.labelLarge,
          fontWeight = FontWeight.Medium,
          color = MaterialTheme.colorScheme.onSurface,
        )
        Text(
          text = stringResource(R.string.lock_hint_text),
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
      }
    }
  }
}

@Composable
private fun LastExecutionCard(result: ShellExecutionResult) {
  Card(
    shape = RoundedCornerShape(10.dp),
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow),
    modifier = Modifier
      .fillMaxWidth()
      .testTag("last_execution_card"),
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(14.dp),
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(
          imageVector = Icons.Rounded.Terminal,
          contentDescription = null,
          tint = if (result.isGreenCommand) FreezeGreen else FreezeRedBright,
          modifier = Modifier.size(18.dp),
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
          text =
            "${stringResource(R.string.last_command_title)} · ${
              if (result.isGreenCommand) "Xanh (trên)" else "Đỏ (dưới)"
            } · Exit ${result.exitCode}",
          style = MaterialTheme.typography.labelMedium,
          color = MaterialTheme.colorScheme.onSurface,
        )
      }
      if (result.command.isNotBlank()) {
        Spacer(modifier = Modifier.height(6.dp))
        Text(
          text = "$ ${result.command}",
          style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace),
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
      }
      if (result.output.isNotBlank()) {
        Spacer(modifier = Modifier.height(4.dp))
        Text(
          text = result.output,
          style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace),
          color = if (result.success) MaterialTheme.colorScheme.onSurface else FreezeRedBright,
        )
      }
    }
  }
}

@Preview(showBackground = true)
@Composable
private fun MainScreenPreview() {
  FreezeShellTheme {
    MainScreen(
      uiState =
        MainUiState(
          rootStatus = RootStatus.GRANTED,
          isFloatingEnabled = true,
          buttonSizeDp = 82,
        ),
      onTopShellChanged = {},
      onBottomShellChanged = {},
      onSaveConfig = {},
      onToggleFloatingButton = {},
      onButtonSizeChanged = {},
      onRequestRoot = {},
      onSnackbarShown = {},
    )
  }
}
