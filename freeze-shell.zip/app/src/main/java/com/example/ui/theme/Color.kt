package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val CobaltBlue = Color(0xFF1976D2)
val CobaltBlueDark = Color(0xFF1565C0)
val CobaltBlueLight = Color(0xFFE3F2FD)

val FreezeRed = Color(0xFFC62828)
val FreezeRedBright = Color(0xFFD32F2F)
val FreezeGreen = Color(0xFF2E7D32)
val FreezeGreenLight = Color(0xFFE8F5E9)
val FreezeRedLight = Color(0xFFFFEBEE)

val SurfaceLight = Color(0xFFF8FAFC)
val SurfaceCardLight = Color(0xFFFFFFFF)
val OnSurfaceDark = Color(0xFF1E242B)
val OnSurfaceMuted = Color(0xFF5A6573)
val OutlineSubtle = Color(0xFFD0D8E2)

val SurfaceDark = Color(0xFF0F141A)
val SurfaceCardDark = Color(0xFF182028)
val OnSurfaceLight = Color(0xFFEBF0F5)
val OnSurfaceMutedDark = Color(0xFF9AA7B5)
val OutlineSubtleDark = Color(0xFF2E3A46)
