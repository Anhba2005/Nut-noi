package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme =
  darkColorScheme(
    primary = Color(0xFF64B5F6),
    onPrimary = Color(0xFF082542),
    primaryContainer = Color(0xFF0D47A1),
    onPrimaryContainer = Color(0xFFE3F2FD),
    secondary = FreezeRedBright,
    onSecondary = Color.White,
    tertiary = FreezeGreen,
    onTertiary = Color.White,
    background = SurfaceDark,
    onBackground = OnSurfaceLight,
    surface = SurfaceDark,
    onSurface = OnSurfaceLight,
    surfaceContainerLow = SurfaceCardDark,
    onSurfaceVariant = OnSurfaceMutedDark,
    outline = OutlineSubtleDark,
  )

private val LightColorScheme =
  lightColorScheme(
    primary = CobaltBlue,
    onPrimary = Color.White,
    primaryContainer = CobaltBlueLight,
    onPrimaryContainer = CobaltBlueDark,
    secondary = FreezeRedBright,
    onSecondary = Color.White,
    tertiary = FreezeGreen,
    onTertiary = Color.White,
    background = SurfaceLight,
    onBackground = OnSurfaceDark,
    surface = SurfaceLight,
    onSurface = OnSurfaceDark,
    surfaceContainerLow = SurfaceCardLight,
    onSurfaceVariant = OnSurfaceMuted,
    outline = OutlineSubtle,
  )

@Composable
fun FreezeShellTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  content: @Composable () -> Unit,
) {
  val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

  MaterialTheme(
    colorScheme = colorScheme,
    typography = Typography,
    content = content,
  )
}
